﻿// ====================================================
// More Templates: https://www.ebenmonney.com/templates
// Email: support@ebenmonney.com
// ====================================================

using $safeprojectname$.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace $safeprojectname$.Repositories.Interfaces
{
    public interface IOrdersRepository : IRepository<Order>
    {

    }
}
