﻿// =============================
// Email: info@ebenmonney.com
// www.ebenmonney.com/templates
// =============================

using $safeprojectname$.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace $safeprojectname$.Repositories.Interfaces
{
    public interface IProductRepository : IRepository<Product>
    {

    }
}
