﻿// =============================
// Email: info@ebenmonney.com
// www.ebenmonney.com/templates
// =============================

using System;

namespace $safeprojectname$.Core
{
    public enum Gender
    {
        None,
        Female,
        Male
    }
}
