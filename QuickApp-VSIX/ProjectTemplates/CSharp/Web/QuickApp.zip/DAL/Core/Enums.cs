﻿// ====================================================
// More Templates: https://www.ebenmonney.com/templates
// Email: support@ebenmonney.com
// ====================================================

using System;

namespace $safeprojectname$.Core
{
    public enum Gender
    {
        None,
        Female,
        Male
    }
}
