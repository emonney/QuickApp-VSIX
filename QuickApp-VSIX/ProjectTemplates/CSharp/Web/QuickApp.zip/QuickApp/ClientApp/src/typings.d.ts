// ====================================================
// More Templates: https://www.ebenmonney.com/templates
// Email: support@ebenmonney.com
// ====================================================

/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
