// =============================
// Email: info@ebenmonney.com
// www.ebenmonney.com/templates
// =============================

import { AppPage } from './app.po';

describe('$safeprojectname$ App', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should display application title: $safeprojectname$', () => {
        page.navigateTo();
        expect(page.getAppTitle()).toEqual('$safeprojectname$');
    });
});
